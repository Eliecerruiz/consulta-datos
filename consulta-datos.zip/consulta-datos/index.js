const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Rutas protegidas
const USER_PASSWORD = 'consultar123';
const ADMIN_PASSWORD = 'admin123';

// Autenticación básica
app.post('/api/login', (req, res) => {
  const { password } = req.body;
  if (password === USER_PASSWORD) return res.json({ role: 'user' });
  if (password === ADMIN_PASSWORD) return res.json({ role: 'admin' });
  return res.status(401).json({ error: 'Clave incorrecta' });
});

// Buscar por número
app.get('/api/buscar/:numero', (req, res) => {
  const numero = req.params.numero;
  const data = JSON.parse(fs.readFileSync('./datos.json', 'utf8'));
  const resultado = data.find(reg => reg.numero === numero);
  if (resultado) {
    res.json(resultado);
  } else {
    res.status(404).json({ error: 'No encontrado' });
  }
});

// Agregar nuevo registro (solo admin)
app.post('/api/agregar', (req, res) => {
  const { nombre, tipo, numero, estado } = req.body;
  if (!nombre || !tipo || !numero || !estado) {
    return res.status(400).json({ error: 'Datos incompletos' });
  }

  const data = JSON.parse(fs.readFileSync('./datos.json', 'utf8'));
  if (data.find(r => r.numero === numero)) {
    return res.status(400).json({ error: 'Ya existe ese número' });
  }

  const nuevo = { nombre, tipo, numero, estado };
  data.push(nuevo);
  fs.writeFileSync('./datos.json', JSON.stringify(data, null, 2));
  res.json({ mensaje: 'Registro agregado' });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});